@echo off
setlocal
cd /d "%~dp0"
title QT SYNC ICC - Reparar dependencias

if not exist ".venv\Scripts\python.exe" (
    echo Ambiente virtual nao encontrado.
    echo Execute primeiro: 1_INSTALAR.bat
    pause
    exit /b 1
)

echo Reinstalando dependencias...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install --upgrade --force-reinstall -r requirements.txt

echo.
echo Testando...
".venv\Scripts\python.exe" -c "import streamlit, pandas, reportlab; print('Dependencias OK')"
echo.
pause
