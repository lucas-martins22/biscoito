@echo off
setlocal
cd /d "%~dp0"
title QT SYNC ICC

if not exist ".venv\Scripts\python.exe" (
    echo O aplicativo ainda nao foi instalado.
    echo Execute primeiro: 1_INSTALAR.bat
    pause
    exit /b 1
)

echo ==========================================
echo ABRINDO QT SYNC ICC
echo ==========================================
echo.
echo O navegador deve abrir automaticamente.
echo Se nao abrir, use:
echo http://localhost:8501
echo.
echo Para encerrar o servidor, pressione CTRL+C.
echo.

".venv\Scripts\python.exe" -m streamlit run app.py --server.headless false
pause
