
from io import BytesIO
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether
)

def _safe(value):
    if value is None:
        return "-"
    return str(value).replace("–", "-").replace("—", "-")

def _p(text, style):
    return Paragraph(_safe(text), style)

def build_pdf_report(
    patients,
    history,
    chair_rows,
    metrics,
    pharmacy,
    alerts,
    generated_at=None,
    title="QT SYNC ICC - Relatorio Operacional do Dia",
):
    """Gera o relatorio PDF do estado atual do MVP e retorna bytes."""
    generated_at = generated_at or datetime.now()
    buffer = BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=14 * mm,
        leftMargin=14 * mm,
        topMargin=15 * mm,
        bottomMargin=15 * mm,
        title=title,
        author="QT SYNC ICC",
    )

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="QTTitle",
        parent=styles["Title"],
        fontName="Helvetica-Bold",
        fontSize=18,
        leading=22,
        alignment=TA_CENTER,
        spaceAfter=8,
    ))
    styles.add(ParagraphStyle(
        name="QTSub",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        leading=12,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#555555"),
        spaceAfter=12,
    ))
    styles.add(ParagraphStyle(
        name="Section",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=12,
        leading=14,
        spaceBefore=8,
        spaceAfter=6,
        textColor=colors.HexColor("#183B56"),
    ))
    styles.add(ParagraphStyle(
        name="Small",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.4,
        leading=9.2,
    ))
    styles.add(ParagraphStyle(
        name="Tiny",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=6.4,
        leading=8,
    ))
    styles.add(ParagraphStyle(
        name="Note",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=7.2,
        leading=9,
        textColor=colors.HexColor("#666666"),
    ))

    story = [
        _p(title, styles["QTTitle"]),
        _p(
            f"Gerado em {generated_at.strftime('%d/%m/%Y %H:%M:%S')} - "
            "Secretaria / Central de Navegacao da Quimioterapia",
            styles["QTSub"],
        ),
    ]

    story.append(_p("1. Resumo do turno", styles["Section"]))
    summary_data = [
        ["Indicador", "Valor"],
        ["Pacientes monitorados", metrics.get("patients_total", 0)],
        ["Pacientes com alta", metrics.get("patients_discharged", 0)],
        ["Pacientes em infusao", metrics.get("patients_infusion", 0)],
        ["Eventos capturados", metrics.get("events", 0)],
        ["Aguardando proxima acao", metrics.get("patients_waiting", 0)],
        ["Indice de sincronizacao", f"{metrics.get('sync_index', 0):.0f}%"],
        ["Tempo morto estimado", f"{metrics.get('dead_time_min', 0):.0f} min"],
    ]
    table = Table(summary_data, colWidths=[105 * mm, 55 * mm], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#183B56")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTNAME", (0,1), (0,-1), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.3, colors.HexColor("#BFC8D2")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F5F7F9")]),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 5),
        ("RIGHTPADDING", (0,0), (-1,-1), 5),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    story.extend([table, Spacer(1, 7)])

    story.append(_p("2. Situacao dos pacientes", styles["Section"]))
    patient_data = [["Paciente", "Protocolo", "Etapa atual", "Espera", "Poltrona", "Proxima acao"]]
    for p in patients:
        patient_data.append([
            _p(p.get("id", "-"), styles["Small"]),
            _p(p.get("protocolo", "-"), styles["Small"]),
            _p(p.get("etapa_nome", "-"), styles["Small"]),
            _p(f"{p.get('espera', 0)} min", styles["Small"]),
            _p(p.get("poltrona") if p.get("poltrona") is not None else "-", styles["Small"]),
            _p(p.get("proxima_acao", "-"), styles["Small"]),
        ])
    ptable = Table(
        patient_data,
        colWidths=[18*mm, 43*mm, 29*mm, 18*mm, 18*mm, 47*mm],
        repeatRows=1,
    )
    ptable.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#183B56")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#C7CFD8")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F7F9FB")]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("FONTSIZE", (0,0), (-1,-1), 7.3),
        ("LEFTPADDING", (0,0), (-1,-1), 3),
        ("RIGHTPADDING", (0,0), (-1,-1), 3),
        ("TOPPADDING", (0,0), (-1,-1), 3),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    story.extend([ptable, Spacer(1, 7)])

    story.append(_p("3. Poltronas", styles["Section"]))
    chair_data = [["Poltrona", "Status", "Paciente", "Protocolo", "Detalhe"]]
    for c in chair_rows:
        chair_data.append([
            _p(c.get("Poltrona", "-"), styles["Small"]),
            _p(c.get("Status", "-"), styles["Small"]),
            _p(c.get("Paciente", "-"), styles["Small"]),
            _p(c.get("Protocolo", "-"), styles["Small"]),
            _p(c.get("Detalhe", "-"), styles["Small"]),
        ])
    ctable = Table(chair_data, colWidths=[20*mm, 33*mm, 25*mm, 45*mm, 50*mm], repeatRows=1)
    ctable.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#35647A")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#C7CFD8")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F7F9FB")]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("FONTSIZE", (0,0), (-1,-1), 7.3),
        ("LEFTPADDING", (0,0), (-1,-1), 3),
        ("RIGHTPADDING", (0,0), (-1,-1), 3),
        ("TOPPADDING", (0,0), (-1,-1), 3),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    story.extend([ctable, Spacer(1, 7)])

    section4 = [_p("4. Farmacia / CMQ e alertas", styles["Section"])]
    pharm_data = [
        ["Indicador", "Quantidade"],
        ["Aguardando manipulacao", pharmacy.get("waiting", 0)],
        ["Em manipulacao", pharmacy.get("mixing", 0)],
        ["QT pronta", pharmacy.get("ready", 0)],
    ]
    ftable = Table(pharm_data, colWidths=[105*mm, 55*mm], repeatRows=1)
    ftable.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#35647A")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTNAME", (0,1), (0,-1), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#C7CFD8")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F7F9FB")]),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("LEFTPADDING", (0,0), (-1,-1), 5),
        ("RIGHTPADDING", (0,0), (-1,-1), 5),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    section4.extend([ftable, Spacer(1, 5)])
    if alerts:
        for a in alerts:
            section4.append(_p(f"- {a}", styles["Small"]))
    else:
        section4.append(_p("Nenhuma excecao critica registrada no momento da geracao.", styles["Small"]))
    story.append(KeepTogether(section4))
    story.append(Spacer(1, 6))

    story.append(_p("5. Log de eventos", styles["Section"]))
    event_data = [["Horario", "Paciente", "Protocolo", "De", "Para", "Poltrona"]]
    if history:
        for e in history:
            event_data.append([
                _p(e.get("Horario", "-"), styles["Tiny"]),
                _p(e.get("Paciente", "-"), styles["Tiny"]),
                _p(e.get("Protocolo", "-"), styles["Tiny"]),
                _p(e.get("De", "-"), styles["Tiny"]),
                _p(e.get("Para", "-"), styles["Tiny"]),
                _p(e.get("Poltrona", "-"), styles["Tiny"]),
            ])
    else:
        event_data.append(["-", "-", "Nenhum evento registrado", "-", "-", "-"])

    etable = Table(
        event_data,
        colWidths=[21*mm, 21*mm, 48*mm, 29*mm, 29*mm, 22*mm],
        repeatRows=1,
    )
    etable.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#183B56")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.2, colors.HexColor("#CCD3DB")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F7F9FB")]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("FONTSIZE", (0,0), (-1,-1), 6.5),
        ("LEFTPADDING", (0,0), (-1,-1), 2.5),
        ("RIGHTPADDING", (0,0), (-1,-1), 2.5),
        ("TOPPADDING", (0,0), (-1,-1), 2.5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 2.5),
    ]))
    story.extend([etable, Spacer(1, 8)])

    story.append(_p("6. Observacoes", styles["Section"]))
    story.append(_p(
        "Este relatorio foi gerado pelo MVP QT SYNC ICC. Na versao de demonstracao, "
        "os pacientes, protocolos, tempos e resultados sao ficticios e servem exclusivamente "
        "para demonstrar a logica de captura de eventos, monitoramento de fluxo e geracao de dados. "
        "Em uso institucional, os limites de alerta, indicadores e integracoes devem ser validados "
        "pelo Hospital Haroldo Juacaba / ICC.",
        styles["Note"],
    ))

    def footer(canvas, doc_obj):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#777777"))
        canvas.drawString(14 * mm, 8 * mm, "QT SYNC ICC - MVP")
        canvas.drawRightString(A4[0] - 14 * mm, 8 * mm, f"Pagina {doc_obj.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buffer.getvalue()
