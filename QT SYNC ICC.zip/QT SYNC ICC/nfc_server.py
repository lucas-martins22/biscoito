import json
import time
import uuid
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs


HOST = "0.0.0.0"
PORT = 8765

EVENT_FILE = Path(__file__).resolve().parent / "nfc_event.json"

COOLDOWN_SECONDS = 3
last_scan = {}


def save_event(patient):
    event = {
        "event_id": str(uuid.uuid4()),
        "patient": patient,
        "timestamp": time.time(),
    }

    # gravação atômica para evitar que o Streamlit leia
    # o arquivo enquanto ele ainda está sendo escrito
    temporary = EVENT_FILE.with_suffix(".tmp")

    temporary.write_text(
        json.dumps(event),
        encoding="utf-8",
    )

    temporary.replace(EVENT_FILE)


class NFCHandler(BaseHTTPRequestHandler):

    def do_GET(self):

        parsed = urlparse(self.path)

        # Teste simples para conferir se o celular
        # consegue alcançar o notebook
        if parsed.path == "/health":

            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()

            self.wfile.write(b"QT SYNC NFC OK")

            return

        if parsed.path != "/scan":
            self.send_response(404)
            self.end_headers()
            return

        params = parse_qs(parsed.query)

        patient = params.get("patient", [None])[0]

        if patient is None:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"Paciente nao informado.")
            return

        patient = patient.upper()

        # Evita que a mesma aproximação da tag
        # gere vários eventos rapidamente
        now = time.monotonic()

        previous = last_scan.get(patient, 0)

        if now - previous < COOLDOWN_SECONDS:

            self.send_response(200)
            self.send_header(
                "Content-Type",
                "text/html; charset=utf-8"
            )
            self.end_headers()

            self.wfile.write(
                f"""
                <html>
                    <body style="font-family: Arial; text-align:center;">
                        <h2>QT SYNC</h2>
                        <p>Leitura duplicada ignorada.</p>
                        <p>Paciente: <b>{patient}</b></p>
                    </body>
                </html>
                """.encode("utf-8")
            )

            return

        last_scan[patient] = now

        save_event(patient)

        print(f"NFC recebido: {patient}")

        self.send_response(200)

        self.send_header(
            "Content-Type",
            "text/html; charset=utf-8"
        )

        self.end_headers()

        self.wfile.write(
            f"""
            <html>
                <body style="
                    font-family: Arial;
                    text-align:center;
                    margin-top:50px;
                ">
                    <h1>QT SYNC</h1>

                    <h2>✓ Leitura registrada</h2>

                    <p>
                        Paciente:
                        <b>{patient}</b>
                    </p>

                    <p>
                        Evento enviado ao dashboard.
                    </p>
                </body>
            </html>
            """.encode("utf-8")
        )


print("=" * 50)
print("QT SYNC - RECEPTOR NFC")
print("=" * 50)
print(f"Servidor iniciado na porta {PORT}")
print("Pressione CTRL+C para encerrar.")

server = ThreadingHTTPServer(
    (HOST, PORT),
    NFCHandler
)

server.serve_forever()