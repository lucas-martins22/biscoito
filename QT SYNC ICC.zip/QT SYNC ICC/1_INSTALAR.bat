@echo off
setlocal
cd /d "%~dp0"
title QT SYNC ICC - Instalacao

echo ==========================================
echo QT SYNC ICC - INSTALACAO AUTOMATICA
echo ==========================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    set "PYCMD=py"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PYCMD=python"
    ) else (
        echo ERRO: Python nao foi encontrado.
        echo.
        echo Instale o Python 3.10 ou superior.
        echo Durante a instalacao, marque "Add Python to PATH".
        echo Depois execute este arquivo novamente.
        pause
        exit /b 1
    )
)

echo [1/5] Verificando Python...
%PYCMD% --version
if errorlevel 1 goto :erro

echo.
echo [2/5] Criando ambiente virtual .venv...
if not exist ".venv\Scripts\python.exe" (
    %PYCMD% -m venv .venv
    if errorlevel 1 goto :erro
) else (
    echo Ambiente virtual ja existe.
)

echo.
echo [3/5] Atualizando pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :erro

echo.
echo [4/5] Instalando Streamlit, Pandas e ReportLab...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :erro

echo.
echo [5/5] Testando dependencias...
".venv\Scripts\python.exe" -c "import streamlit, pandas, reportlab; print('Dependencias OK')"
if errorlevel 1 goto :erro

echo.
echo ==========================================
echo INSTALACAO CONCLUIDA COM SUCESSO
echo ==========================================
echo.
echo Agora de dois cliques em:
echo 2_ABRIR_QT_SYNC.bat
echo.
pause
exit /b 0

:erro
echo.
echo ==========================================
echo OCORREU UM ERRO NA INSTALACAO
echo ==========================================
echo Copie a mensagem exibida acima e envie ao suporte.
pause
exit /b 1
