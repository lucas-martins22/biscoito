
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from report_utils import build_pdf_report

st.set_page_config(
    page_title="QT SYNC ICC",
    page_icon="Q",
    layout="wide",
)

STAGES = [
    "Triagem",
    "Apto",
    "Poltrona",
    "Manipulacao",
    "QT pronta",
    "Infusao",
    "Concluida",
    "Alta",
]

NEXT_ACTION = {
    "Triagem": "Concluir triagem",
    "Apto": "Alocar poltrona",
    "Poltrona": "Disparar manipulacao",
    "Manipulacao": "Aguardar QT pronta",
    "QT pronta": "Iniciar infusao",
    "Infusao": "Finalizar QT",
    "Concluida": "Liberar paciente/poltrona",
    "Alta": "Fluxo encerrado",
}

CHAIRS = list(range(1, 11))

INITIAL_PATIENTS = [
    {"id": "P001", "protocolo": "Paclitaxel", "duracao": 60, "etapa": 0, "espera": 2, "poltrona": None},
    {"id": "P002", "protocolo": "Doxorrubicina + Ciclofosfamida (AC)", "duracao": 45, "etapa": 1, "espera": 5, "poltrona": None},
    {"id": "P003", "protocolo": "R-CHOP", "duracao": 180, "etapa": 2, "espera": 4, "poltrona": 1},
    {"id": "P004", "protocolo": "Cisplatina", "duracao": 240, "etapa": 3, "espera": 9, "poltrona": 2},
    {"id": "P005", "protocolo": "CAPOX / XELOX", "duracao": 120, "etapa": 4, "espera": 3, "poltrona": 3},
    {"id": "P006", "protocolo": "Rituximabe", "duracao": 180, "etapa": 5, "espera": 0, "poltrona": 4},
    {"id": "P007", "protocolo": "Paclitaxel + Carboplatina", "duracao": 180, "etapa": 1, "espera": 7, "poltrona": None},
    {"id": "P008", "protocolo": "Gemcitabina", "duracao": 60, "etapa": 0, "espera": 1, "poltrona": None},
    {"id": "P009", "protocolo": "Trastuzumabe + Pertuzumabe", "duracao": 90, "etapa": 2, "espera": 6, "poltrona": 5},
    {"id": "P010", "protocolo": "Irinotecano", "duracao": 120, "etapa": 3, "espera": 11, "poltrona": 6},
]

def fresh_patients(clock):
    data = []
    for p in INITIAL_PATIENTS:
        item = dict(p)
        item["etapa_iniciada"] = clock - timedelta(minutes=item["espera"])
        data.append(item)
    return data

def init_state():
    if "clock" not in st.session_state:
        st.session_state.clock = datetime(2026, 9, 30, 8, 0, 0)
    if "patients" not in st.session_state:
        st.session_state.patients = fresh_patients(st.session_state.clock)
    if "events" not in st.session_state:
        st.session_state.events = 0
    if "history" not in st.session_state:
        st.session_state.history = []
    if "report_pdf" not in st.session_state:
        st.session_state.report_pdf = None
    if "finished" not in st.session_state:
        st.session_state.finished = False

def reset():
    st.session_state.clock = datetime(2026, 9, 30, 8, 0, 0)
    st.session_state.patients = fresh_patients(st.session_state.clock)
    st.session_state.events = 0
    st.session_state.history = []
    st.session_state.report_pdf = None
    st.session_state.finished = False

def current_wait(p):
    if p["etapa"] >= 7:
        return 0
    delta = st.session_state.clock - p["etapa_iniciada"]
    return max(0, int(delta.total_seconds() // 60))

def free_chair():
    used = {
        p["poltrona"]
        for p in st.session_state.patients
        if p["poltrona"] is not None and p["etapa"] < 7
    }
    for c in CHAIRS:
        if c not in used:
            return c
    return None

def invalidate_report():
    st.session_state.report_pdf = None
    st.session_state.finished = False

def advance_patient(patient_id, minutes=2):
    p = next((x for x in st.session_state.patients if x["id"] == patient_id), None)
    if p is None or p["etapa"] >= 7:
        return False

    invalidate_report()
    old_stage = STAGES[p["etapa"]]

    if p["etapa"] == 1 and p["poltrona"] is None:
        p["poltrona"] = free_chair()
        if p["poltrona"] is None:
            return False

    st.session_state.clock += timedelta(minutes=minutes)
    p["etapa"] += 1

    if p["etapa"] == 2 and p["poltrona"] is None:
        p["poltrona"] = free_chair()

    if p["etapa"] >= 7:
        p["poltrona"] = None

    p["etapa_iniciada"] = st.session_state.clock
    st.session_state.events += 1

    st.session_state.history.append({
        "Horario": st.session_state.clock.strftime("%H:%M:%S"),
        "Paciente": p["id"],
        "Protocolo": p["protocolo"],
        "De": old_stage,
        "Para": STAGES[p["etapa"]],
        "Poltrona": p["poltrona"] if p["poltrona"] is not None else "-",
    })
    return True

def advance_priority():
    active = [p for p in st.session_state.patients if p["etapa"] < 7]
    if not active:
        return False
    active.sort(key=lambda p: (-current_wait(p), -p["etapa"], p["id"]))
    for p in active:
        if p["etapa"] == 1 and p["poltrona"] is None and free_chair() is None:
            continue
        return advance_patient(p["id"])
    return False

def run_steps(n):
    for _ in range(n):
        if not advance_priority():
            break

def finish_simulation(max_steps=100):
    for _ in range(max_steps):
        if all(p["etapa"] >= 7 for p in st.session_state.patients):
            break
        if not advance_priority():
            break

def patient_rows():
    rows = []
    for p in st.session_state.patients:
        stage_name = STAGES[p["etapa"]]
        rows.append({
            "Paciente": p["id"],
            "Protocolo": p["protocolo"],
            "Duracao prevista (min)": p["duracao"],
            "Etapa atual": stage_name,
            "Espera (min)": current_wait(p),
            "Poltrona": p["poltrona"] if p["poltrona"] is not None else "-",
            "Proxima acao": NEXT_ACTION[stage_name],
        })
    return rows

def chair_rows():
    rows = []
    for chair in CHAIRS:
        occupant = next(
            (p for p in st.session_state.patients if p["poltrona"] == chair and p["etapa"] < 7),
            None,
        )
        if occupant is None:
            rows.append({
                "Poltrona": f"{chair:02d}",
                "Status": "Livre",
                "Paciente": "-",
                "Protocolo": "-",
                "Detalhe": "Disponivel",
            })
        else:
            stage = STAGES[occupant["etapa"]]
            rows.append({
                "Poltrona": f"{chair:02d}",
                "Status": stage,
                "Paciente": occupant["id"],
                "Protocolo": occupant["protocolo"],
                "Detalhe": f"{current_wait(occupant)} min nesta etapa",
            })
    return rows

def pharmacy_metrics():
    return {
        "waiting": sum(1 for p in st.session_state.patients if p["etapa"] == 2),
        "mixing": sum(1 for p in st.session_state.patients if p["etapa"] == 3),
        "ready": sum(1 for p in st.session_state.patients if p["etapa"] == 4),
    }

def current_alerts():
    out = []
    for p in st.session_state.patients:
        w = current_wait(p)
        if p["etapa"] == 1 and w >= 10:
            out.append(f"{p['id']} esta apto ha {w} min e ainda nao possui poltrona.")
        if p["etapa"] == 3 and w >= 8:
            out.append(f"{p['id']} aguarda QT ha {w} min na poltrona {p['poltrona']}.")
        if p["etapa"] == 4 and w >= 6:
            out.append(f"{p['id']} esta com QT pronta ha {w} min sem inicio de infusao.")
    return out

def metrics():
    patients_total = len(st.session_state.patients)
    discharged = sum(1 for p in st.session_state.patients if p["etapa"] == 7)
    infusion = sum(1 for p in st.session_state.patients if p["etapa"] == 5)
    waiting = sum(1 for p in st.session_state.patients if p["etapa"] in [1,2,3,4])
    dead_time = sum(current_wait(p) for p in st.session_state.patients if p["etapa"] in [1,2,3,4])
    sync = min(98, 55 + discharged * 3 + min(st.session_state.events, 25))
    return {
        "patients_total": patients_total,
        "patients_discharged": discharged,
        "patients_infusion": infusion,
        "patients_waiting": waiting,
        "events": st.session_state.events,
        "dead_time_min": dead_time,
        "sync_index": sync,
    }

def report_patient_rows():
    rows = []
    for p in st.session_state.patients:
        stage = STAGES[p["etapa"]]
        rows.append({
            "id": p["id"],
            "protocolo": p["protocolo"],
            "etapa_nome": stage,
            "espera": current_wait(p),
            "poltrona": p["poltrona"],
            "proxima_acao": NEXT_ACTION[stage],
        })
    return rows

def generate_report():
    st.session_state.report_pdf = build_pdf_report(
        patients=report_patient_rows(),
        history=st.session_state.history,
        chair_rows=chair_rows(),
        metrics=metrics(),
        pharmacy=pharmacy_metrics(),
        alerts=current_alerts(),
        generated_at=datetime.now(),
    )
    st.session_state.finished = True

init_state()

st.title("QT SYNC ICC")
st.caption(
    "MVP funcional com 10 pacientes ficticios - Secretaria como Central de Navegacao"
)

m = metrics()
k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Pacientes", m["patients_total"])
k2.metric("Em infusao", m["patients_infusion"])
k3.metric("Com alta", m["patients_discharged"])
k4.metric("Aguardando acao", m["patients_waiting"])
k5.metric("Eventos capturados", m["events"])

st.markdown("### Controle da simulacao")
c1, c2, c3, c4, c5 = st.columns([1,1,1,1.2,1.6])

if c1.button("Avancar 1 evento", use_container_width=True):
    advance_priority()
    st.rerun()

if c2.button("Avancar 10 eventos", use_container_width=True):
    run_steps(10)
    st.rerun()

if c3.button("Finalizar simulacao", use_container_width=True):
    finish_simulation()
    st.rerun()

if c4.button("Reiniciar", use_container_width=True):
    reset()
    st.rerun()

c5.info(f"Horario simulado: **{st.session_state.clock.strftime('%H:%M:%S')}**")

with st.expander("Avancar um paciente especifico"):
    available_ids = [p["id"] for p in st.session_state.patients if p["etapa"] < 7]
    if available_ids:
        sel = st.selectbox("Paciente", available_ids)
        selected = next(p for p in st.session_state.patients if p["id"] == sel)
        st.write(
            f"**{sel}** - {selected['protocolo']} | "
            f"Etapa: **{STAGES[selected['etapa']]}** | "
            f"Espera: **{current_wait(selected)} min**"
        )
        if st.button("Avancar paciente selecionado"):
            if advance_patient(sel):
                st.rerun()
            else:
                st.warning("Nao ha poltrona disponivel para essa transicao.")
    else:
        st.success("Todos os pacientes ja receberam alta.")

st.markdown("---")

left, right = st.columns([1.65, 1])

with left:
    st.subheader("Fila operacional em tempo real")
    df_patients = pd.DataFrame(patient_rows())
    st.dataframe(df_patients, use_container_width=True, hide_index=True)

with right:
    st.subheader("Farmacia / CMQ")
    pharm = pharmacy_metrics()
    p1, p2, p3 = st.columns(3)
    p1.metric("Aguardando", pharm["waiting"])
    p2.metric("Manipulacao", pharm["mixing"])
    p3.metric("QT pronta", pharm["ready"])

    st.subheader("Alertas")
    alerts = current_alerts()
    if alerts:
        for a in alerts:
            st.warning(a)
    else:
        st.success("Nenhuma excecao critica neste momento.")

st.markdown("### Poltronas")
st.dataframe(pd.DataFrame(chair_rows()), use_container_width=True, hide_index=True)

st.markdown("### Indicadores do turno")
m = metrics()
i1, i2, i3, i4 = st.columns(4)
i1.metric("Tempo morto acumulado", f"{m['dead_time_min']} min")
i2.metric("Indice de sincronizacao", f"{m['sync_index']:.0f}%")
i3.metric("Pacientes concluidos", f"{m['patients_discharged']}/10")
i4.metric("Eventos registrados", m["events"])
st.progress(m["sync_index"] / 100, text="Sincronizacao do fluxo")

st.markdown("### Log de eventos")
if st.session_state.history:
    st.dataframe(
        pd.DataFrame(st.session_state.history)[::-1],
        use_container_width=True,
        hide_index=True,
    )
else:
    st.info("Ainda nao ha eventos registrados.")

st.markdown("---")
st.markdown("### Relatorio do dia em PDF")
st.write(
    "Ao encerrar a demonstracao, gere um relatorio com o estado dos 10 pacientes, "
    "poltronas, indicadores, Farmacia/CMQ, alertas e todo o log de eventos."
)

r1, r2 = st.columns([1, 2])
if r1.button("Encerrar dia e gerar PDF", use_container_width=True):
    generate_report()
    st.rerun()

if st.session_state.report_pdf:
    filename = f"Relatorio_QT_SYNC_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    r2.download_button(
        "Baixar relatorio PDF",
        data=st.session_state.report_pdf,
        file_name=filename,
        mime="application/pdf",
        use_container_width=True,
    )
    st.success("Relatorio pronto para download.")
else:
    r2.info("O botao de download aparecera depois de gerar o relatorio.")

st.markdown("---")
st.markdown(
    """
**Mensagem para a banca:** o QT SYNC nao substitui o TASY. Ele organiza os eventos
do processo em uma visao operacional unica, mede os tempos entre as etapas e
permite que a Secretaria gerencie excecoes e antecipe o proximo passo.

**Importante:** esta versao usa 10 pacientes e tempos ficticios para demonstracao.
"""
)
